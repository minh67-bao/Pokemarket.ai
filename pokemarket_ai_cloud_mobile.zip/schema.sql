create table if not exists cards (
 id bigserial primary key, canonical_name text not null, set_name text, card_number text,
 language text, variant text, pokemon text, rarity text, artwork_url text,
 unique(canonical_name, language, variant)
);
create table if not exists sales (
 id bigserial primary key, card_id bigint references cards(id), provider text not null,
 marketplace text, listing_id text, sold_at timestamptz, currency char(3),
 sold_price numeric, shipping numeric default 0, condition text, grade_company text,
 grade text, source_url text, verified boolean default false,
 unique(provider, listing_id)
);
create table if not exists populations (
 id bigserial primary key, card_id bigint references cards(id), grading_company text,
 grade text, population integer, snapshot_date date, source text
);
create table if not exists fx_rates (
 rate_date date, currency char(3), aud_per_unit numeric, primary key(rate_date,currency)
);
create table if not exists forecasts (
 id bigserial primary key, card_id bigint references cards(id), condition text,
 horizon_days integer, lower_aud numeric, median_aud numeric, upper_aud numeric,
 model_version text, generated_at timestamptz default now(), sample_size integer
);
