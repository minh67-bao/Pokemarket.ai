# POKÉMARKET AI — mobile-first cloud prototype

## Recommended hosting path
Start with Streamlit Community Cloud for a low-cost prototype. It is suitable for a dashboard, but not for continuous background scraping or a production data pipeline. Add Supabase for persistent storage and a separate scheduled worker (Render or similar) when authorised data feeds are connected.

## Deploy from your phone
1. Create a GitHub account if you do not already have one.
2. Create a new **private** repository named `pokemarket-ai`.
3. Upload `app.py`, `requirements.txt`, and this README from the extracted ZIP. Keep the folder structure if you upload all files.
4. In Streamlit Community Cloud, connect GitHub and select the repository, branch `main`, and `app.py`.
5. Deploy. Open the resulting HTTPS URL on your iPhone and use Safari's Share → Add to Home Screen.

You must complete the GitHub and Streamlit account steps yourself. Do not send passwords or API keys in chat.

## Current functionality
- Responsive mobile-first dashboard
- Filters for era and condition
- Balanced, fast-growth and long-term-value ranking modes
- Card research panel with Pokémon, set, artwork, scarcity and liquidity factors
- Forecast horizon selector
- Explicit demo labels

**All sample data is illustrative.** This version does not have live eBay, PSA, BGS, CGC, FX or population connections. Scores and forecast scenarios are not investment recommendations.

## Production architecture
- Streamlit frontend
- Supabase Postgres database and scheduled snapshots
- Scheduled worker on Render for permitted provider API ingestion
- Provider adapters for global eBay sold data and licensed market data
- Separate population snapshots for PSA, BGS and CGC
- Historical FX rates for sale-date AUD conversion
- Forecast training and walk-forward backtests

## Data model (minimum)
`cards`: canonical identity, set, card number, language, variant, Pokémon, rarity, artwork URL
`sales`: provider, marketplace, listing ID, sold date, currency, sold price, shipping, condition, grade, source URL, verification status
`populations`: grading company, grade, population, snapshot date
`fx_rates`: date, currency, AUD rate
`features`: valuation, scarcity, popularity, artwork, momentum, liquidity, sample size
`forecasts`: card ID, condition, horizon, predicted range, model version, generated timestamp

## Important ingestion rules
Use only authorised APIs or data providers. Do not scrape in ways that violate provider terms. Exclude asking prices and unknown accepted-offer amounts from sold-price medians. Deduplicate source listing IDs and probable cross-market duplicates. Keep raw/graded and language/printing variants distinct.
